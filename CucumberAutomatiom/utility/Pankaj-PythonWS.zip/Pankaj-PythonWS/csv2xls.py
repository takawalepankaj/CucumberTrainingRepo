import xlwt

f = open("marks.csv","r")
wb = xlwt.Workbook()
ws = wb.add_sheet ("Marks")

for rowNum,line in enumerate(f):
    for colNum,data in enumerate (line.rstrip().split(",")):
        ws.write(rowNum,colNum,data)


wb.save("newmarks.xls")

f.close()
