def average(*num):
    print(type(num))
    print(num)
    print(float(sum(num))/len(num))


average(3,4)
average(3,4,5)
average(3,4,6.8,90,34,34,56.9)
