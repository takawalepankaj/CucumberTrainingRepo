#sorting lists

a=[1,3,5,7,3,4,12,11,34,32,67,45]

b=sorted(a)
print(b)#sort as numbers ascending
print(sorted(a,reverse=True))#sort as numbers descending
print(sorted(a,key=lambda x:str(x))) #sort as string

##print(sorted(a,key=lamda x:x.lower()))

b=["simla","Ooty","Leh","Srinagar","Mahabaleshwar","Araku"]

print(sorted(b))
print(sorted(b,key=lambda x:x.lower())) # sort by lower case of element
print(sorted(b,key=lambda x:len(x))) # sort by length of element
