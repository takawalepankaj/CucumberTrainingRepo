f=open("input1.txt","a")
f.write("\nThis is new line")
f.close()
