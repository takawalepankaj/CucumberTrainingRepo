##f=open("input.txt","r")
##
##for line in f:
##    words = 0
##    words = len(line.split(" "))
##    print("[" + line.rstrip() + "] contains {} words".format(words))
##f.close()



f=open("input.txt","r")

for lineNo, line in enumerate (f):
        
    print("Line {} contains {} words".format(lineNo+1,len(line.rstrip().split())))
f.close()
