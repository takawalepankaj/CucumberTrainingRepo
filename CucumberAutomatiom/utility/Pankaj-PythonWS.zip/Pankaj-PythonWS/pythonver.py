import requests
from bs4 import BeautifulSoup 

url="https://www.python.org/downloads/"

r = requests.get(url)

soup = BeautifulSoup(r.text,"html5lib")

p = soup.find("p",attrs={'class':'download-buttons'})



ver = p.findAll("a")


print(ver[0].text)

print(ver[0].text.split()[-1])

#h1 = soup.find("h1",attrs={'text':'Download the latest version for Windows'})
h1 = soup.findAll(text='Download the latest version for Windows')              

print(h1[0])
        


##div2 = h1.findAll("a")

##print(div2[0].text)
