from selenium import webdriver
browser = webdriver.Firefox();
browser.get("http://indianblooddonors.com")

##name = browser.find_element_by_id("Full_Name")
##name.send_keys("Pankaj S. Takawale")
##
##bGroup = browser.find_element_by_id("Blood_Group")
##bGroup.send_keys("O +ve")
##
##
##stdcode_id = browser.find_element_by_id("stdcode_id")
##stdcode_id.send_keys("020")
##
##Pincode = browser.find_element_by_id("Pincode")
##Pincode.send_keys("412307")
##
##Mobile_Number = browser.find_element_by_id("Mobile_Number")
##Mobile_Number.send_keys("9890647214")
##
##Email = browser.find_element_by_id("Email")
##Email.send_keys("takawale.pankaj@gmail.com")
##
##pwd = browser.find_element_by_id("pwd")
##pwd.send_keys("Pass@1234")
##
##
##cpwd = browser.find_element_by_id("cpwd")
##cpwd.send_keys("Pass@1234")
##
##
##cpwd = browser.find_element_by_name("REGISTER")
##cpwd.click()
##
unsub = browser.find_element_by_link_text("Unsubscribe")
unsub.click()







