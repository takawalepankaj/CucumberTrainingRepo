import requests
from datetime import datetime

url ="http://www.mongofactory.com/apis/postdumppython.php"
payload = {'name':'Pankaj','loc':'Pune','date':datetime.today()}

#latlong = "{},{}".format(s,f)
#ddd = {'Lat_Long':latlong}

#r = requests.get(url,params=ddd)
r = requests.post(url,data=payload)

if r.ok:
    output=r.text
    print(output)
