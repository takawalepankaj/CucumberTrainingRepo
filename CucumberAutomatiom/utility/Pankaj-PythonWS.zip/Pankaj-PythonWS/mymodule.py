i=45
COMPANY = "Synechron"
def add(x,y):
    return x+y
