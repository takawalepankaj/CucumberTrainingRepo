import mymodule

print (mymodule.i)
print(mymodule.COMPANY)
print(mymodule.add(4,5))
