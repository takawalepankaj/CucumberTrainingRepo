import fileinfo
import os
import time

class NewFileInfo(fileinfo.FileInfo):
    def getmtime(self):
        print (time.ctime(os.path.getmtime(self.filename)))

    def getsize(self):
        print("{} bytes".format(os.path.getsize(self.filename)))

        
f=NewFileInfo("input.txt")
f.getmtime()
f.getlinecount()
f.firstline()
f.lastline()
f.nthline(3)
f.getage()
f.getsize()
f.search("new")

f.close()
