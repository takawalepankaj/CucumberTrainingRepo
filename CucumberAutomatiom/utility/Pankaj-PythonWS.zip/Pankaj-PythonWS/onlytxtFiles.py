##import os
##for (dirname, subdir, files) in os.walk('c:\\'):
##    for myfile in files:
##            if (len(myfile.split(".txt"))>1):
##                filename=os.path.join(dirname,myfile)
##                print(filename)
##            

##import os
##for (dirname, subdir, files) in os.walk('c:\\'):
##    for myfile in files:
##        if (myfile.endswith(".txt")):
##            filename=os.path.join(dirname,myfile)
##            print(filename)

##import os
##for (dirname, subdir, files) in os.walk('c:\\'):
##    size = 5*1024*1024*1024
##    for myfile in files:
##        filename=os.path.join(dirname,myfile)
##        print("File [{}] , {}".format( filename,os.path.getsize(filename)))
##        if (os.path.getsize(filename)>size):            
##            print(filename)

import os
import time
curTime=time.time()
print(curTime)
for (dirname, subdir, files) in os.walk('c:\\'):
    
    for myfile in files:
        filename=os.path.join(dirname,myfile)
        creationTime=os.path.getctime(filename)
        print("File [{}] creation Time {},   Current TIme {}".format( filename,creationTime, curTime))
        if ((curTime-creationTime)<(48*60*60)):            
            print(filename)
