a=input("Enter number 1:");
b=input("Enter number 2:");

print(int(a)+int(b));
