import os
import glob
import zipfile
home="C:/Users/Admin/Desktop/Pankaj-PythonWS"
pattern="*.py"
target="C:/Users/Admin/Desktop/PythonWS.zip"

os.chdir (home)
files2bzipped =glob.glob(pattern)
z=zipfile.ZipFile(target,"w")

for file in files2bzipped:
    z.write(file)


z.close()



