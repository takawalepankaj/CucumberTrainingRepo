import os
import time
class FileInfo:
    def __init__(self,filename):
        self.filename=filename
        self.f=open(filename,"r")
        self.lines=self.f.readlines()
    def getlinecount(self):
        print(len(self.lines))
    def firstline(self):
        self.nthline(1)
    def lastline(self):
        self.nthline(0)
    def nthline(self,lineno):
        print(self.lines[lineno-1])
    def getage(self):
        now=time.time()
        ctime=os.path.getctime(self.filename)
        age = (now - ctime)/60/60/24 # days
        print(age)
    def getsize(self):
        print(os.path.getsize(self.filename))
    def search(self,searchtext):
        for lineno,line in enumerate(self.lines):
            if searchtext in line:
                print(lineno+1,line.rstrip())


    
    def close(self):
        self.f.close()

