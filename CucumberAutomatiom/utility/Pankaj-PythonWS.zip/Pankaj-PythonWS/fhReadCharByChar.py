f= open("input.txt","r")
print(f.read(1))
print(f.read(1))
f.close()
