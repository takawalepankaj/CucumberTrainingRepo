a=[56,9,8,8,89,89]
print(set(a))
