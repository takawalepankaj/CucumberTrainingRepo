f=open("input.txt","r")

for line in f:
    #print(line.rstrip())
    print(line,end="")

f.close()
