import os
#make list of IP
ips=["www.google.com","www.hellowelcome123232323.com","localhost","127.0.0.1"]

def isUp(ip):
    pingStatus = "ping {} -n 1 > NUL".format(ip)
    status = os.system(pingStatus)
    return not status

while True:
    for ip in ips:
        if (isUp(ip)):
            print("{} is up".format(ip))
        else:
            print("{} is down".format(ip))

    break

