def this_fails():
    x = 1/0

try:
    this_fails()
except ZeroDivisionError as err:
    print ('Check your denominator.\n The system generated error is', err)
