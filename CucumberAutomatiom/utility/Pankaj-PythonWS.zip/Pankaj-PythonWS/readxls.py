import xlrd

wb = xlrd.open_workbook("newmarks.xls")
ws = wb.sheet_by_index(0)

print (ws.cell(0,0))
print(wb.sheet_names())

print(ws.nrows)
print(ws.ncols)

rows = ws.nrows
cols = ws.ncols

for x in range (0,rows):
    print (ws.row(x))

for row in range(0,ws.nrows):
    for col in range(0,ws.ncols):
        print (ws.cell(row,col).value)
    
