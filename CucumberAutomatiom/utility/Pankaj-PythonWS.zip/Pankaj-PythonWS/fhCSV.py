f=open("marks.csv","r")

for line in f:
    data = line.rstrip().split(",")
    name = data[0]
    averageMarks = (int(data[1])+int(data[2])+int(data[3]))/3

    print ("Average marks of Student {} is {}".format(name,averageMarks)) 
    
f.close()
f=open("marks.csv","r")
def studentAvg(name,*num):
    print("Length : {}".format(len(num)))    
    print("Sudent Name: {} , Average Marks : {}".format(name,round(sum(num)/len(num),2)))

for line in f:
    a,b,c,d=line.rstrip().split(",")
    data = line.rstrip().split(",")
    name = data[0]
    
    studentAvg(name,int(data[1]),int(data[2]),int(data[3]))
    
f.close()
