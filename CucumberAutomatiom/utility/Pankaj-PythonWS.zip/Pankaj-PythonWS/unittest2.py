import unittest 

def square(x): #function to test
	return x+x


class TestAverage(unittest.TestCase): 
	def test_average1(self): 
		self.assertEqual(square(2),4)
		self.assertEqual(square(0),0)
		self.assertRaises(TypeError, square, "hi")
# This invokes all tests
unittest.main()
