import xlwt
wb=xlwt.Workbook()
ws =wb.add_sheet("test sheet")
ws.write(0,0,"Name")
ws.write(0,1,"Marks")

ws.write(1,0,"Ramesh")
ws.write(1,1,81)

ws.write(2,0,"Ravi")
ws.write(2,1,89)

wb.save("C:\\Users\\Admin\\Desktop\\Pankaj-PythonWS\\example.xls")
