import xlwt
import xlrd

f=open("marks.csv","r")

wb=xlwt.Workbook()
ws =wb.add_sheet("Marks")

ws.write(0,0,"Name")
ws.write(0,1,"Mark1")
ws.write(0,2,"Mark2")
ws.write(0,3,"Mark3")


for rowNum,line in enumerate(f):
    name,mark1,mark2,mark3=line.rstrip().split(",")
    ws.write(rowNum+1,0,name)
    ws.write(rowNum+1,1,mark1)
    ws.write(rowNum+1,2,mark2)
    ws.write(rowNum+1,3,mark3)
    

wb.save("marks.xls")
f.close()




