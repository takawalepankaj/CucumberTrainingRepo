##def diff1(x,y):
##    if (x > y):
##        return x-y   
##    else:
##        return y-x
##    
##def add(x,y=10):
##    return x+y
##    
##print(add(8))
##print(add(8,2))
##print(add(8,3),add(7))
###c=diff1(5,2)
###print(c)
###print(diff1(2,5))

##def wish(name,age):
##    print("Hello {} you are {} years old".format(name,age))
##
##wish("India",67)
##wish(67,"India")
##
##wish(age=67,name='India')

##def sumdiff(a,b):
##    return a+b,abs(a-b)
##
##print (type(sumdiff(4,9)))
##
##mysum,mydiff=sumdiff(4,9)
##print(mysum,mydiff)
##print(sumdiff(4,9))


           
