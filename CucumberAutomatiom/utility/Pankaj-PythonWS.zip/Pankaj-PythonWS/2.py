def add(x,y):
    return x+y
    

c=add(4,5)
print(c)
print(add(5,6))
