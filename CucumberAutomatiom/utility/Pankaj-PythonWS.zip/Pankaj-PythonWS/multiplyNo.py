import sys

number1 = sys.argv [1]
number2 = sys.argv [2]

print(int(number1)*int(number2))
print(len(sys.argv ))
print(sys.argv[0])
