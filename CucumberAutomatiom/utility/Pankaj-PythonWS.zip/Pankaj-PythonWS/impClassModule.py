import baby
pinky=baby.Baby("Haritha")
pinky.cry() #print ("I am crying")
pinky.laugh() #print ("ha ha ha")
pinky.hi() # print ("Hello, I am Haritha")

