class Dog:
    def __init__(self,color,breed):
        self.color = color
        self.breed = breed
    def speak(self):
        print ("bhou..bhou")
    def guard(self):
        print ("I am guarding your home")

##tommy = Dog()
##
##print(type(tommy))
##tommy.speak()
##tommy.guard()

tommy = Dog()
print(tommy.color)
tommy1 = Dog("brown","lab")
tommy1.speak()
print(tommy1.color)
