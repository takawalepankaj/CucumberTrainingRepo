f=open("input.txt","r")
print(f.read())
f.close()
