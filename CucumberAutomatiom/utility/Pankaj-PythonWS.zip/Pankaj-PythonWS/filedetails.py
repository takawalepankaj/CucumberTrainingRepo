import fileinfo
f=fileinfo.FileInfo("input.txt")

print(f.getlinecount())
f.firstline()
f.lastline()
f.nthline(3)
f.getage()
f.getsize()
f.search("new")
f.close()
