f=open("input.txt","r")
print(f.readline())
print(f.readline())
f.close()
