import requests
import json

#get the current position of international space station
url="http://api.open-notify.org/iss-now.json"

print("Getting ISS lat long")
r = requests.get(url)

print(r.text)
response=json.loads(r.text)


print(response.get('iss_position'))
lat=response.get('iss_position').get('latitude')
long=response.get('iss_position').get('longitude')

print(lat,long)
