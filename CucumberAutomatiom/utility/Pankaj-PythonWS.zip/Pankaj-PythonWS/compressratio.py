import os
import glob
import zipfile
 
home="C:/Users/Admin/Desktop/Pankaj-PythonWS"
pattern="*.py"
target="C:/Users/Admin/Desktop/PythonWS.zip"

os.chdir (home)
files2bzipped =glob.glob(pattern)
z=zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED )
allfilesize=0
for file in files2bzipped:
    z.write(file)
    allfilesize+=os.path.getsize(file) 

z.close()

zipfilesize=os.path.getsize(target)

print ("Compression ratio : {} %".format(round((zipfilesize/allfilesize)*100),2)) 



