
f=open("marks.csv","r")
def studentAvg(name,num):
    print("Length : {}".format(len(num)))
    
    print("Sudent Name: {} , Average Marks : {}".format(name,round(sum(num)/len(num),2)))

for line in f:
    fields=line.rstrip().split(",")
    name=fields[0]
    subjects=[]

    for x in fields[1:]:
        subjects.append(int(x))
        
    studentAvg(name,subjects)
f.close()
