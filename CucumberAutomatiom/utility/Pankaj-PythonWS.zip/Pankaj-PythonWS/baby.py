class Baby:
    def __init__(self, name):
        self.name = name
    def cry(self):
        print ("I am crying")
    def laugh(self):
        print ("ha.ha.ha")
    def hi(self):
        print ("Hello, I am {}".format(self.name))
